# __init__.py (root level)
"""Bike Share Model Package."""
# Version identifier
__version__ = '0.1.0'