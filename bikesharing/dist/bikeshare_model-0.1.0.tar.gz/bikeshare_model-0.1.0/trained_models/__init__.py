# trained_models/__init__.py
"""Trained models module for the bike share model."""
